package miultimorepasogentedeseenmesuerte;

/**
Un libro posee título, nombre
de su primer autor y peso
 */

public class Libro {
    private String titulo;
    private String primAutor;
    private double peso;

    // Los libros a partir de toda su información
    public Libro(String titulo, String primAutor, double peso) {
        this.setTitulo(titulo);
        this.setPrimAutor(primAutor);
        this.setPeso(peso);
    }
    
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getPrimAutor() {
        return primAutor;
    }
    public void setPrimAutor(String primAutor) {
        this.primAutor = primAutor;
    }

    public double getPeso() {
        return peso;
    }
    public void setPeso(double peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "{ Titulo = " + titulo + ", primer autor = " + primAutor + ", peso = " + peso + " }";
    }
}