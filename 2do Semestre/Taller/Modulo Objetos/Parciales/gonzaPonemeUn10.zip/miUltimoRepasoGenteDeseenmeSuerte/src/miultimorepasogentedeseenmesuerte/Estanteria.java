package miultimorepasogentedeseenmesuerte;

/**
Una estantería mantiene sus libros
organizados en N estantes cada uno con lugar para M libros
 */

public class Estanteria {
    private int numEstantes;
    private int numLugares;
    private Libro [][] matLibros;
    private int matDimL = 0;
    
    public Estanteria(int numEstantes, int numLugares) {
        this.numEstantes = numEstantes;
        this.numLugares = numLugares;
        this.matLibros = new Libro [this.numEstantes][this.numLugares];
    }
    
    //almacenarLibro: recibe un libro y un nro. de estante válido, y lo almacena en el primer
    //lugar libre de dicho estante. Asuma que hay espacio para almacenar el libro.
    public void almacenarLibro(Libro unLibro, int nroEstante) {
        this.matLibros[nroEstante][matDimL % numLugares] = unLibro;
        this.matDimL++;
    }
    
    //- sacarLibro: saca y devuelve el libro que se encuentra en el estante X, lugar Y (X e Y se
    //reciben y son válidos). Dicho lugar debe quedar disponible.
    public Libro sacarLibro(int nroEstante, int nroLugar) {
        Libro libroSacado = null;
        
        if (this.matLibros[nroEstante][nroLugar] != null) {
            libroSacado = this.matLibros[nroEstante][nroLugar];
            this.matLibros[nroEstante][nroLugar] = null;
            System.out.println("SISTEMA: Se ha liberado la posición " + nroEstante + "/" + nroLugar);
        } else {
            System.out.println("ERROR: No se ha encontrado libro en dicha posición");
        }
        
        return libroSacado;
    }
    
    //- Calcular: calcula y devuelve el número del estante más pesado (teniendo en cuenta el
    //peso de sus libros).
    public int calcular() {
        int estanteMax = -1;
        double pesoEstante = 0;
        double pesoMax = 0;
        
        for (int i = 0; i < this.numEstantes; i++) {
            for (int j = 0; j < this.numLugares; j++) {
                if (this.matLibros[i][j] != null)
                    pesoEstante = pesoEstante + this.matLibros[i][j].getPeso();
            }
            if (pesoEstante > pesoMax) {
                pesoMax = pesoEstante;
                estanteMax = i;
                System.out.println(estanteMax + " " + pesoEstante);
            }
            pesoEstante = 0;
        }
        
        return estanteMax + 1;
    }
    
    public String toString() {
        String aux = "ESTANTERÍA: ";
        
        for (int i = 0; i < this.matDimL; i++) {
            if (this.matLibros[i / this.numLugares][i % this.numLugares] != null)
                aux = aux + "ESTANTE." + ((i / this.numLugares)+1) + " NRO." + (i+1) + " / "+ this.matLibros[i / this.numLugares][i % this.numLugares].toString() + "\n";
        }
        
        return aux;
    }
}