package miultimorepasogentedeseenmesuerte;

/**
Queremos representar estanterías de libros. Una estantería mantiene sus libros
organizados en N estantes cada uno con lugar para M libros. Un libro posee título, nombre
de su primer autor y peso.
* 
a) Implemente las clases de su modelo, con sus atributos y getters/setters adecuados.
Provea constructores para iniciar: los libros a partir de toda su información; la estantería
para N estantes y lugar para M libros por estante (inicialmente no debe tener libros
cargados).
* 
- almacenarLibro: recibe un libro y un nro. de estante válido, y lo almacena en el primer
lugar libre de dicho estante. Asuma que hay espacio para almacenar el libro.
* 
- sacarLibro: saca y devuelve el libro que se encuentra en el estante X, lugar Y (X e Y se
reciben y son válidos). Dicho lugar debe quedar disponible.
* 
- Calcular: calcula y devuelve el número del estante más pesado (teniendo en cuenta el
peso de sus libros).
* 
- toString:
 */
import PaqueteLectura.GeneradorAleatorio;

public class MiUltimoRepasoGenteDeseenmeSuerte {
    
    public static void main(String[] args) {
        int numLugares = 3;
        Estanteria est = new Estanteria(5, numLugares);
        Libro nueLibro;
        
        GeneradorAleatorio.iniciar();
        
        //Generar libros
        for (int i = 0; i < 3; i++) {
            nueLibro = new Libro(GeneradorAleatorio.generarString(5), "Borges", GeneradorAleatorio.generarInt(10));
            est.almacenarLibro(nueLibro, 0);
        }
        for (int i = 0; i < 3; i++) {
            nueLibro = new Libro(GeneradorAleatorio.generarString(5), "Spinoza", GeneradorAleatorio.generarInt(10));
            est.almacenarLibro(nueLibro, 1);
        }
        for (int i = 0; i < 3; i++) {
            nueLibro = new Libro(GeneradorAleatorio.generarString(5), "HUme", GeneradorAleatorio.generarInt(10));
            est.almacenarLibro(nueLibro, 2);
        }
        
        System.out.println(est.toString());
        est.sacarLibro(1, 0);
        System.out.println("El estante mas pesado es el " + est.calcular());
    }
    
}
